package com.example.msipc.petr;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.text.ParseException;

class Activity1 extends Activity
{

    public static int MapOut;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity1);
    }

    public void fotka(View v)       //funkce pro zjištění RGB hodnot pixelů mapy
    {
        EditText e1 = (EditText)findViewById(R.id.editText);
        EditText e2 = (EditText)findViewById(R.id.editText2);

        if(e1.getText().toString().length() == 0 || e2.getText().toString().length() == 0)
            Toast.makeText(this, "povinné", Toast.LENGTH_SHORT).show();
        else {
            try
            {
            float x = Float.valueOf(e1.getText().toString()).floatValue();
            float y = Float.valueOf(e2.getText().toString()).floatValue();

            Bitmap bitmap;

            bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.heatmap);

            x -= 48.55181f;
            x /= 2.503897f;

            y -= 12.09081f;
            y /= 6.768442f;
            y = 1 - y;

            if (x < 0 || x > 1 || y < 0 || y > 1) {
                Toast.makeText(this, "Mimo oblast ČR", Toast.LENGTH_SHORT).show();

            } else {

                //TextView t1 = (TextView) findViewById(R.id.txt);

                int color = bitmap.getPixel((int) (x * bitmap.getWidth()), (int) (y * bitmap.getHeight()));  //kompenzace scalingu

                int red = Color.red(color);//(color & 0x00ff0000) >> 16;
                int green = Color.green(color);//(color & 0x0000ff00) >> 8;
                int blue = Color.blue(color);//color & 0x000000ff;


                if (red >= 250 && red <= 255 && blue >= 250 && blue <= 255 && green >= 250 && green <= 255)  //nalezne barvu na heatmapě
                {
                    Toast.makeText(this, "Mimo oblast ČR", Toast.LENGTH_SHORT).show();

                } else {   //určování barvy
                    if (red >= 170 && red <= 180 && green >= 0 && green <= 5) {
                        MapOut = 1300;
                    } else if (red >= 195 && red <= 205 && green >= 0 && green <= 5) {
                        MapOut = 1220;
                    } else if (red >= 235 && red <= 245 && green >= 95 && green <= 103) {
                        MapOut = 1184;
                    } else if (red >= 250 && red <= 255 && green >= 135 && green <= 145) {
                        MapOut = 1156;
                    } else if (red >= 250 && red <= 255 && green >= 175 && green <= 183) {
                        MapOut = 1128;
                    } else if (red >= 250 && red <= 255 && green >= 198 && green <= 205) {
                        MapOut = 1100;
                    } else {
                        MapOut = 1070;
                    }
                    //t1.setText(Integer.toString((MapOut)));
                    startActivity(new Intent(this, Activity2.class));
                }
            }
        }catch(NumberFormatException nfe){
                Toast.makeText(this, "neplatná hodnota", Toast.LENGTH_SHORT).show();
        }
    }

    }
}
class Activity2 extends Activity
{

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity2);
        Button next = (Button) findViewById(R.id.button5);
        next.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View view)
            {//linkování klikací funkce
                EditText t1 = (EditText)findViewById(R.id.Ucinost_text);  //
                EditText t2 = (EditText)findViewById(R.id.Metry_text);
                EditText t3 = (EditText)findViewById(R.id.editText2);
                Bundle bundle2 = new Bundle();  //vytvoreni balíků
                Bundle bundle3 = new Bundle();
                Bundle bundle4 = new Bundle();
                float c2 = Float.valueOf(t1.getText().toString()).floatValue();
                int c3 = Integer.parseInt(t2.getText().toString());
                int c4 = Integer.parseInt(t3.getText().toString());
                bundle2.putFloat("Maras2",c2);  //ukládáníhodnot do balíku
                bundle3.putInt("Maras3" ,c3);
                bundle4.putInt("Maras4" ,c4);
                Intent MyIntent = new Intent(view.getContext(), Activity3.class);
                MyIntent.putExtras(bundle3);  //posílá proměnné do aktivity 3
                MyIntent.putExtras(bundle2);
                MyIntent.putExtras(bundle4);
                startActivityForResult(MyIntent, 0);
            }

        });
    }

}
class Activity3 extends Activity {

    /**
     * Called when the activity is first created.
     */
    Context ctxt = this;
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity3);

        Button next = (Button) findViewById(R.id.button);
        next.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                try {  //testuje chybu
                    Bundle bundle = getIntent().getExtras();
                    Float Maras2 = bundle.getFloat("Maras2");//rozbaluje balíčky azískává hodnoty
                    Integer Maras3 = bundle.getInt("Maras3");
                    Integer Maras4 = bundle.getInt("Maras4");
                    EditText t1 = (EditText) findViewById(R.id.Cena_el);
                    float c1 = Float.valueOf(t1.getText().toString()).floatValue();
                    TextView t2 = (TextView) findViewById(R.id.Mes_Energie);  //definuje proměnné jako textbox
                    TextView t3 = (TextView) findViewById(R.id.Roc_Energie);
                    TextView t4 = (TextView) findViewById(R.id.Mes_utrata);
                    TextView t5 = (TextView) findViewById(R.id.Roc_utrata);
                    TextView t6 = (TextView) findViewById(R.id.Celkem);
                    float me = (Activity1.MapOut * Maras2 * Maras3) / 12.0f;    //výpočet
                    float re = Activity1.MapOut * Maras2 * Maras3;
                    float mu = (Activity1.MapOut * Maras2 * Maras3 * c1) / 12f;
                    float ru = Activity1.MapOut * Maras2 * Maras3 * c1;
                    float celkem = (Maras3 * Maras4) / ru;

                    t2.setText(Float.toString(me)); //vypisování do textboxu
                    t3.setText(Float.toString(re));
                    t4.setText(Float.toString(mu));
                    t5.setText(Float.toString(ru));

                    t6.setText(Float.toString(celkem));

                }catch(NumberFormatException nfe)   //pokud nastane chyba
                {

                    Toast.makeText(ctxt, "neplatná hodnota", Toast.LENGTH_SHORT).show();

                }

                /*Intent intent = new Intent();
                setResult(RESULT_OK, intent);
                finish();*/
            }

        });
    }
}