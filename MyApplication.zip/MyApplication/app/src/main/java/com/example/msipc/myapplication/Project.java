

package com.example.msipc.myapplication;

import android.annotation.SuppressLint;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class Project extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_project);
    }

    public void funkce(View v)
    {
        EditText e1 = (EditText)findViewById(R.id.Cena_el);
        TextView t1 = (TextView)findViewById(R.id.Mes_Energie);
        TextView t2 = (TextView)findViewById(R.id.Roc_Energie);
        TextView t3 = (TextView)findViewById(R.id.Mes_utrata);
        TextView t4 = (TextView)findViewById(R.id.Roc_utrata);
        int cena = Integer.parseInt(e1.getText() .toString());
        int me = 50;//x - Nahradi se v dalsi casti programu
        int re = 600;//y - Nahradi se v dalsi casti programu
        int mu = cena*50;
        int ru = cena*600;
        t1.setText(Integer.toString(me));
        t2.setText(Integer.toString(re));
        t3.setText(Integer.toString(mu));
        t4.setText(Integer.toString(ru));

    }
}
