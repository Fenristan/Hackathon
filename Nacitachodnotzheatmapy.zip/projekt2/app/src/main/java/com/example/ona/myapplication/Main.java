package com.example.ona.myapplication;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.io.File;

import static java.lang.Math.max;
import static java.lang.Math.min;

public class Main extends AppCompatActivity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    public void fotka(View v)       //funkce pro zjištění RGB hodnot pixelů mapy
    {
        int x = 63;
        int y = 37;

        Bitmap bitmap;

        bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.heatmap);
        TextView t1 = (TextView)findViewById(R.id.txt);
        int color = bitmap.getPixel((int)(x * bitmap.getWidth()/406f), (int)(y * bitmap.getHeight()/150f));  //vzorec pro scaling

        int red = Color.red(color);//(color & 0x00ff0000) >> 16;
        int green = Color.green(color);//(color & 0x0000ff00) >> 8;
        int blue = Color.blue(color);//color & 0x000000ff;


        if (red >= 250 && red <= 255 && blue >= 250 && blue <= 255 && green >= 250 && green <= 255)  //nalezne barvu na heatmapě
        {
            t1.setText("0");
        }

        else if (red >= 170 && red <= 180 && green >= 0 && green <= 5)
        {
            t1.setText("7");
        }

        else if (red >= 195 && red <= 205 && green >= 0 && green <= 5)
        {
            t1.setText("6");
        }

        else if (red >= 235 && red <= 245 && green >= 95 && green <= 103)
        {
            t1.setText("5");
        }

        else if (red >= 250 && red <= 255 && green >= 135 && green <= 145)
        {
            t1.setText("4");
        }

        else if (red >= 250 && red <= 255 && green >= 175 && green <= 183)
        {
            t1.setText("3");
        }

        else if (red >= 250 && red <= 255 && green >= 198 && green <= 205)
        {
            t1.setText("2");
        }

        else
        {
            t1.setText("1");
        }

    }
}
