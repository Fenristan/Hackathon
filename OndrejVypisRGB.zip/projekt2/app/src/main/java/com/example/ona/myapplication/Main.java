package com.example.ona.myapplication;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.io.File;

public class Main extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    public void fotka(View v)       //funkce pro zjištění RGB hodnot pixelů mapy
    {
        Bitmap bitmap;
        int x = 400;
        int y = 350;
        TextView t1 = (TextView) findViewById(R.id.RedNmr1);
        bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.help);
        int color = bitmap.getPixel(x, y);
        int red = Color.red(color);//(color & 0x00ff0000) >> 16;
        int green = Color.green(color);//(color & 0x0000ff00) >> 8;
        int blue = Color.blue(color);//color & 0x000000ff;
        t1.setText(Integer.toString (red) + " " + (blue) + " " + (green));        //vypíše se do text boxu červená hodnota RGB

    }
}