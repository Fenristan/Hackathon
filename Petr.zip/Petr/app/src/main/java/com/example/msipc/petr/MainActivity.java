package com.example.msipc.petr;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

class Activity1 extends Activity
{
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity1);
        Button next = (Button) findViewById(R.id.Button01);
        next.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View view)
            {
                EditText t1 = (EditText)findViewById(R.id.Cislo);
                int c1 = Integer.parseInt(t1.getText() .toString());
                Bundle bundle = new Bundle();
                bundle.putInt("Maras",c1);
                Intent myIntent = new Intent(view.getContext(), Activity2.class);
                myIntent.putExtras(bundle);
                startActivityForResult(myIntent, 0);
            }

        });
    }
}
class Activity2 extends Activity
{
    /** Called when the activity is first created. */
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity2);
        Button next = (Button) findViewById(R.id.button5);
        next.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View view)
            {
                EditText t1 = (EditText)findViewById(R.id.Ucinost_text);
                EditText t2 = (EditText)findViewById(R.id.Metry_text);
                EditText t3 = (EditText)findViewById(R.id.editText2);
                Bundle bundle = getIntent().getExtras();
                Integer Maras = bundle.getInt("Maras");
                Bundle bundle1 = new Bundle();
                Bundle bundle2 = new Bundle();
                Bundle bundle3 = new Bundle();
                Bundle bundle4 = new Bundle();
                float c2 = Float.parseFloat(t1.getText() .toString());
                int c3 = Integer.parseInt(t2.getText() .toString());
                int c4 = Integer.parseInt(t3.getText(). toString());
                bundle1.putInt("Maras" ,Maras);
                bundle2.putFloat("Maras2",c2);
                bundle3.putInt("Maras3" ,c3);
                bundle4.putInt("Maras4" ,c4);
                Intent MyIntent = new Intent(view.getContext(), Activity3.class);
                MyIntent.putExtras(bundle1);
                MyIntent.putExtras(bundle3);
                MyIntent.putExtras(bundle2);
                MyIntent.putExtras(bundle4);
                startActivityForResult(MyIntent, 0);
            }

        });
    }
}
class Activity3 extends Activity {

    /**
     * Called when the activity is first created.
     */
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity3);

        Button next = (Button) findViewById(R.id.button);
        next.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Bundle bundle = getIntent().getExtras();
                Integer Maras = bundle.getInt("Maras");
                Float Maras2 = bundle.getFloat("Maras2");
                Integer Maras3 = bundle.getInt("Maras3");
                Integer Maras4 = bundle.getInt("Maras4");
                EditText t1 = (EditText) findViewById(R.id.Cena_el);
                int c1 = Integer.parseInt(t1.getText().toString());
                TextView t2 = (TextView) findViewById(R.id.Mes_Energie);
                TextView t3 = (TextView) findViewById(R.id.Roc_Energie);
                TextView t4 = (TextView) findViewById(R.id.Mes_utrata);
                TextView t5 = (TextView) findViewById(R.id.Roc_utrata);
                TextView t6 = (TextView)findViewById(R.id.Celkem);
                float me = (Maras*Maras2*Maras3)/12.0f;
                float re = Maras*Maras2*Maras3;
                float mu = (Maras*Maras2*Maras3*c1)/12f;
                float ru = Maras*Maras2*Maras3*c1;
                float celkem = (Maras3*Maras4)/ru;

                t2.setText(Float.toString(me));
                t3.setText(Float.toString(re));
                t4.setText(Float.toString(mu));
                t5.setText(Float.toString(ru));
                t6.setText(Float.toString(celkem));

                /*Intent intent = new Intent();
                setResult(RESULT_OK, intent);
                finish();*/
            }

        });
    }
}